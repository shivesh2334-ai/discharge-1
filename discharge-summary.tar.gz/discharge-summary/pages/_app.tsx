// pages/_app.tsx
import type { AppProps } from "next/app";
import Head from "next/head";

export default function App({ Component, pageProps }: AppProps) {
  return (
    <>
      <Head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="description" content="AI-powered clinical discharge summary generator – EMC Digicare" />
        <link rel="icon" href="/favicon.ico" />
        <style>{`
          *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
          body { font-family: 'Inter', system-ui, -apple-system, sans-serif; background: #f0f4f8; }
          @media print {
            .no-print { display: none !important; }
            body { background: white; }
          }
        `}</style>
      </Head>
      <Component {...pageProps} />
    </>
  );
}
